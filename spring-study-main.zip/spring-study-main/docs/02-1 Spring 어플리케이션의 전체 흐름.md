# Spring 어플리케이션의 전체적인 Flow
 - Spring 프로젝트의 기본적인 CRUD의 경우 일반적인 Flow는 다음과 같이 구성된다.
 - 프로젝트 세팅 중 많은 파일들과 설정을 할때마다 큰 Flow를 생각해보고 현재 작성 중인 부분이 어디인지를 인지하고 작성해보자.

![Spring Application Flow](./img/spring%20flow.png)
